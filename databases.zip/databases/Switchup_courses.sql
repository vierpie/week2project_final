-- MySQL dump 10.13  Distrib 8.0.20, for macos10.15 (x86_64)
--
-- Host: localhost    Database: Switchup
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `courses`
--

DROP TABLE IF EXISTS `courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `courses` (
  `courses` varchar(64) DEFAULT NULL,
  `school` varchar(255) DEFAULT NULL,
  `school_id` int NOT NULL,
  `courses_by_group` varchar(255) DEFAULT NULL,
  `courses_id` varchar(255) NOT NULL,
  PRIMARY KEY (`courses_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `courses`
--

LOCK TABLES `courses` WRITE;
/*!40000 ALTER TABLE `courses` DISABLE KEYS */;
INSERT INTO `courses` VALUES ('Bootcamp Prep','app-academy',10525,'other courses','10525_0'),('Software Engineer Track: In-Person','app-academy',10525,'Back end development related course','10525_1'),('Software Engineer Track: Online','app-academy',10525,'Back end development related course','10525_2'),('Data Analytics Bootcamp','ironhack',10828,'data analysis/data science related course','10828_0'),('Data Analytics Part-Time','ironhack',10828,'data analysis/data science related course','10828_1'),('UX/UI Design Bootcamp','ironhack',10828,'UX/UI Design related course','10828_2'),('UX/UI Design Part-Time','ironhack',10828,'UX/UI Design related course','10828_3'),('Web Development Bootcamp','ironhack',10828,'web development related course','10828_4'),('Web Development Part-Time','ironhack',10828,'web development related course','10828_5'),('Web Development Course - Full-Time','le-wagon',10868,'web development related course','10868_0'),('Web Development Course - Part-Time','le-wagon',10868,'web development related course','10868_1'),('Data Science - Full-Time','le-wagon',10868,'data analysis/data science related course','10868_2'),('Data Analytics & Machine Learning','ubiqum-code-academy',11111,'data analysis/data science related course','11111_0'),('Web Development with Java','ubiqum-code-academy',11111,'web development related course','11111_1'),('Web Development with JavaScript','ubiqum-code-academy',11111,'web development related course','11111_2'),('AI Programming with Python','udacity',11118,'data analysis/data science related course','11118_0'),('Al Product Manager','udacity',11118,'other courses','11118_1'),('Cloud Developer','udacity',11118,'other courses','11118_10'),('Computer Vision','udacity',11118,'other courses','11118_11'),('Data Analyst','udacity',11118,'data analysis/data science related course','11118_12'),('Data Engineer','udacity',11118,'data analysis/data science related course','11118_13'),('Data Structures and Algorithms','udacity',11118,'data analysis/data science related course','11118_14'),('Data Visualization','udacity',11118,'data analysis/data science related course','11118_15'),('Deep Learning','udacity',11118,'data analysis/data science related course','11118_16'),('Deep Reinforcement Learning','udacity',11118,'data analysis/data science related course','11118_17'),('Digital Marketing','udacity',11118,'other courses','11118_18'),('Front End Web Developer','udacity',11118,'web development related course','11118_19'),('Android Basics','udacity',11118,'web development related course','11118_2'),('Full Stack Web Developer','udacity',11118,'web development related course','11118_20'),('Introduction to Machine Learning','udacity',11118,'data analysis/data science related course','11118_21'),('Introduction to Programming','udacity',11118,'other courses','11118_22'),('iOS Developer','udacity',11118,'web development related course','11118_23'),('Java Developer','udacity',11118,'web development related course','11118_24'),('Machine Learning Engineer','udacity',11118,'data analysis/data science related course','11118_25'),('Marketing Analytics','udacity',11118,'data analysis/data science related course','11118_26'),('Natural Language Processing','udacity',11118,'data analysis/data science related course','11118_27'),('Predictive Analytics for Business','udacity',11118,'data analysis/data science related course','11118_28'),('React','udacity',11118,'data analysis/data science related course','11118_29'),('Android Developer','udacity',11118,'web development related course','11118_3'),('Robotics Software Engineer','udacity',11118,'Back end development related course','11118_30'),('Self-Driving Car Engineer','udacity',11118,'Back end development related course','11118_31'),('UX Designer','udacity',11118,'UX/UI Design related course','11118_32'),('Artificial Intelligence','udacity',11118,'data analysis/data science related course','11118_4'),('Artificial Intelligence for Trading','udacity',11118,'data analysis/data science related course','11118_5'),('Blockchain Developer','udacity',11118,'other courses','11118_6'),('Business Analytics','udacity',11118,'data analysis/data science related course','11118_7'),('C++','udacity',11118,'other courses','11118_8'),('Cloud Dev Ops Engineer','udacity',11118,'Back end development related course','11118_9');
/*!40000 ALTER TABLE `courses` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-07-10 10:08:35
