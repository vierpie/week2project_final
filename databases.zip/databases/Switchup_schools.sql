-- MySQL dump 10.13  Distrib 8.0.20, for macos10.15 (x86_64)
--
-- Host: localhost    Database: Switchup
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `schools`
--

DROP TABLE IF EXISTS `schools`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schools` (
  `website` varchar(64) DEFAULT NULL,
  `description` varchar(10000) DEFAULT NULL,
  `school` varchar(64) DEFAULT NULL,
  `school_id` int NOT NULL,
  PRIMARY KEY (`school_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schools`
--

LOCK TABLES `schools` WRITE;
/*!40000 ALTER TABLE `schools` DISABLE KEYS */;
INSERT INTO `schools` VALUES ('appacademy.io','App Academy is a coding school that offers online and in-person training programs with no tuition cost until you’re hired as a Software Engineer earning over $50,000. The career changing outcomes that App Academy has produced since being founded in 2012... Read More is a major reason why it’s considered the most respected code school in the industry. App Academy has placed over 3,000 people in full-time Software Engineering roles at average salaries of $101,000 in San Francisco, $90,000 in New York, and $80,000 nationally. Their alumni work at over 1,000 companies worldwide, including Google, Apple, Netflix, Twitter, and more. App Academy understands the skills that make a successful software engineer, and more importantly, how to teach them to you. If you don’t succeed after completing the program, you pay nothing, and that’s how it should be.Read Less','app-academy',10525),('www.ironhack.com','Ironhack is a global tech school with 9 campuses worldwide, located in Miami, Madrid, Barcelona, Paris, Berlin, Amsterdam, Mexico City, Lisbon and São Paulo. Ironhack offers bootcamps and part-time courses in web development, UX/UI design and data analytics,... Read More which are taught both remotely and in-person.With more than 5.000 graduates working at companies like Google, Visa, Twitter, Rocket Internet and Orange, among others, Ironhack has an extensive global network of +600 partner companies. Post graduation, all students have access to career services, which prepare graduates for their job searches and facilitate interviews in their city\'s local tech ecosystem.Read Less','ironhack',10828),('www.lewagon.com','Le Wagon runs immersive coding bootcamps in 39 campuses worldwide. The web development course is designed to teach students the necessary skills to land a job in software development or product management - or prepare them to create their own startup.... Read More Students following the data science course will learn in-demand skills, from Python to advanced Machine Learning, enabling them to join a Data Science team.Le Wagon\'s courses are either full-time or part-time and taught in-person. In 9 weeks or 24 weeks, students learn to build web applications or to explore, clean and transform data into actionable insights, and to collaborate within a team of developers or data scientists using the right tools and workflows.Le Wagon has a global community of 7,500+ alumni, and a strong network of partner companies across all industries to help students find their dream jobs.Read Less','le-wagon',10868),('ubiqum.com','Ubiqum Code Academy\'s highly immersive bootcamps equip students from all backgrounds with the technical skills and experience they need to be 100% employable in the IT and technology sector. Offering courses in full-stack Java development, full-stack... Read More JavaScript development, and Data Analytics &amp; Machine Learning, Ubiqum is one of the few coding bootcamps that offers a guarantee of employment, worth 50% of your course value. Eligible students can pay 50% of their tuition when they start the course and the rest when they get a job. The Ubiqum experience is unique for the learning methodology. They use a \"story-centered curriculum\", which was developed by world-class instructional designers led by Roger C. Schank, founder of the Institute for the Learning Sciences, and well renowned cognitive scientist and AI researcher.  During the program, students work as a professional from day one, taking on the role and tasks of either a junior developer or analyst, thus preparing them for work in such fields.  After completing between 12-20 weeks of practical, \'learn by doing\' training in either data analytics or web development, the students acquire in-demand, specific technical skills that are 100% transferable to the workplace. Students can choose either an onsite program in Barcelona, Madrid, Berlin, or Amsterdam or a remote (online) learning option. Both in person, and online paths include professional mentor support and professional career services.Read Less','ubiqum-code-academy',11111),('www.udacity.com','Udacity is a global technology education provider for anyone who wants a successful career. We power careers by teaching the latest, cutting edge technology. We have a catalog of Nanodegree programs, which teach a number of subjects in a practical way,... Read More leveraging industry expertise. Our unique teaching method, includes real world projects designed with industry experts to deliver the right skills for a successful career, immersive hands-on training with the technical guidance from knowledgeable mentors and career management support to help students meet their career goals. Top technology companies hire Udacity graduates and train their own teams with our Nanodegree programs.Read Less','udacity',11118);
/*!40000 ALTER TABLE `schools` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-07-10 10:08:34
