-- MySQL dump 10.13  Distrib 8.0.20, for macos10.15 (x86_64)
--
-- Host: localhost    Database: Switchup
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `locations`
--

DROP TABLE IF EXISTS `locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `locations` (
  `id` varchar(64) NOT NULL,
  `country_name` varchar(255) DEFAULT NULL,
  `city_name` varchar(255) DEFAULT NULL,
  `school` varchar(255) DEFAULT NULL,
  `school_id` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locations`
--

LOCK TABLES `locations` WRITE;
/*!40000 ALTER TABLE `locations` DISABLE KEYS */;
INSERT INTO `locations` VALUES ('15704','United States','San Francisco','app-academy',10525),('15705','United States','New York City','app-academy',10525),('15803','Australia','Melbourne','le-wagon',10868),('15807',NULL,NULL,'udacity',11118),('15862',NULL,NULL,'app-academy',10525),('15901','Germany','Berlin','ironhack',10828),('15904','Morocco','Casablanca','le-wagon',10868),('15906','Argentina','Buenos Aires','le-wagon',10868),('15913','Germany','Berlin','ubiqum-code-academy',11111),('15964','Belgium','Brussels','le-wagon',10868),('15979','Italy','Milan','le-wagon',10868),('15996','China','Chengdu','le-wagon',10868),('16022','Mexico','Mexico City','ironhack',10828),('16039','Mexico','Mexico City','le-wagon',10868),('16049','Netherlands','Amsterdam','le-wagon',10868),('16086','Netherlands','Amsterdam','ironhack',10828),('16088','Brazil','Sao Paulo','ironhack',10828),('16106','Brazil','Sao Paulo','le-wagon',10868),('16109','France','Paris','ironhack',10828),('16118','Spain','Barcelona','ubiqum-code-academy',11111),('16124','Spain','Barcelona','le-wagon',10868),('16145','France','Bordeaux','le-wagon',10868),('16146','Denmark','Copenhagen','le-wagon',10868),('16147','France','Lille','le-wagon',10868),('16148','Portugal','Lisbon','le-wagon',10868),('16149','Indonesia','Bali','le-wagon',10868),('16150','France','Nantes','le-wagon',10868),('16155','Netherlands','Amsterdam','ubiqum-code-academy',11111),('16274','Brazil','Rio de Janeiro ','le-wagon',10868),('16275','France','Marseille','le-wagon',10868),('16282','Canada','Montreal','le-wagon',10868),('16283','China','Shanghai','le-wagon',10868),('16307','Brazil','Belo Horizonte','le-wagon',10868),('16375','United States','Miami','ironhack',10828),('16376','Spain','Madrid','ironhack',10828),('16377','Spain','Barcelona','ironhack',10828),('16407','Japan','Tokyo','le-wagon',10868),('16408','France','Lyon','le-wagon',10868),('16478','Israel','Tel Aviv','le-wagon',10868),('16570','Japan','Kyoto','le-wagon',10868),('16577','Spain','Madrid','ubiqum-code-academy',11111),('16709','Portugal','Lisbon','ironhack',10828),('16765','Germany','Berlin','le-wagon',10868),('16767','France','Paris','le-wagon',10868),('16775','China','Shenzhen','le-wagon',10868),('16776','Switzerland','Lausanne','le-wagon',10868),('16800','Spain','Madrid','le-wagon',10868),('16804','Norway','Oslo','le-wagon',10868),('16805','France','Rennes','le-wagon',10868),('16936','Singapore','Singapore','le-wagon',10868),('16967','England','London','le-wagon',10868),('16968','Italy','Rome','le-wagon',10868),('17128','Sweden','Stockholm','le-wagon',10868),('17129','South Korea','Seoul','le-wagon',10868),('17157','Turkey','Istanbul','le-wagon',10868),('17188','Canada','Toronto','le-wagon',10868),('17192','Portugal','Lisbon','ubiqum-code-academy',11111),('17233',NULL,NULL,'ironhack',10828),('17314','United Arab Emirates','Dubai','le-wagon',10868);
/*!40000 ALTER TABLE `locations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-07-10 10:08:35
